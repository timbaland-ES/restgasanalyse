function plot_linxon_structure(channel, groupStruct, channelMode, varargin)
% Plot Linxon data from binary file structures
%
% PLOT_LINXON_STRUCTURE(CHANNEL, GROUPSTRUCT, CHANNELMODE, OPTION)
%
% Plots data for channel CHANNELMODE associted with data contained
% in structures CHANNEL, and GROUPSTRUCT where
%
% 	CHANNEL contains information on the configuration of each channel,
%	including its mode
%
%	GROUPSTRUCT contains data for each channel
%
% 	CHANNELMODE is the "Name" of the channel contained in the CHANNEL
% 	structure, such as Single, Sweep, Baseline, TPQuad, etc. 
%
%	If the mode is not found in the CHANNEL structure, an error
%	message is generated with a list of available modes.
%
%	Intentionally providing an invalid channel mode is a convenient
%	way for the user to list available modes in CHANNEL.  This can
%	also be achieved by typing "channel.mode" in the console, assuming
%	the channel structure is stored under its default name "channel"
%
%
% Optional input arguments:
%
%	MULTICHANNELSEMILOGY Uses a log Y axis scale if plotting multiple
%	"Single" type data channels
%
%
% Usage Notes:
%
% If the channel mode to be plotted produces vector data, such as
% Baseline or TPQuad, it will be plotted in 2D.
%
% If the channel mode to be plotted contains matrix data, such as Sweep,
% it will be plotted as a 3D mesh plot.
%
% "Single" data will be plotted as multiple masses on a single 2D axis if
% more than one Single channel is present, otherwise it will be treated as
% vector data.
%
% Note that HEADER is an additional structure produced by
% companion function import_linxon_binary, though it does not
% contain information required for plotting.
%
% Refer to the Linxon API document for additional information
% 
% See also import_linxon_binary

% input argument defaults
multiChannelSemilogY = 0;

% process input arguments
if length(varargin) >= 1
	for argcount = 1:2:length(varargin)-1
		switch lower(char(varargin(argcount)))
			case 'multichannelsemilogy'
				multiChannelSemilogY = varargin{argcount+1};
			otherwise
				fprintf('Warning: switch %s is invalid and was neglected\n',...
					char(varargin(argcount)))
		endswitch
	end
end

chModeSysStatus = 'SystemStatus';
emAffectedModeList = {'Sweep','Single','Baseline','TPQuad','camuUser'};
emAffectedSum = 0;

% convert channel to cell to simplify manipulation
channelCell = struct2cell(channel);
channelModeListCell = cell2mat(channelCell(1,:));	% 1 is the channel mode
channelMatchVect = strcmp(chModeSysStatus,cellstr(channelModeListCell));
channelMatchIdxVect = find(channelMatchVect);
channelPtsPerChanVect = cell2mat(channelCell(9,:));	% 9 is ptsPerChannel

if length(channelMatchVect) == 0
	fprintf('Warning: No SystemStatus channel found, signal polarity may be incorrect\n');
end

if sum(channelMatchVect) > 1
	fprintf('Warning: Multiple SystemStatus channels found, using first instance for polarity\n');
	sysStatdec = groupStruct(1).scanData(1,channelMatchIdxVect(1));
else
	sysStatdec = groupStruct(1).scanData(1,channelMatchIdxVect(1));
end

% use first group to determine system status
fprintf('SystemStatus from groupStruct(1): %X\n', sysStatdec);
emBit = bitand(sysStatdec,hex2dec('800000')); % check for EM (bit 23)

emAffectedSum = sum(strcmp(channelMode,emAffectedModeList));

% todo: more error checking here

% find index of all channels that match channelMode
channelMatchVect = strcmp(channelMode,cellstr(channelModeListCell));
channelMatchIdxVect = find(channelMatchVect);
nChannelsToPlot = length(channelMatchIdxVect);

% if no channelMode not found in data, show error with list of available channel modes
if sum(channelMatchVect) == 0
	% error desired channel name not find in channel.mode list
  fprintf('Error: ''%s'' channelMode was not found in data set\n',channelMode)
  fprintf('List of channel modes in channel structure:\n')
  for kk = 1:length(channelModeListCell)
      fprintf('%d %s\n',kk,char(channelModeListCell(kk)));
  end   
	error('Channel mode not found')
end

% stitch data from individual channels and groups
% build columnSubMatrix with channel data from specified channelMode
% build resultMatrix by adding groups (scans)
% todo: use only one single channel if specified by the user
scanNoVect = [];	% vector to hold final scan numbers for plotting
mzNoVect = [];		% vector to hold final m/z (mass) numbers for plotting
rowIdx = 1;			% index variable to populate scan number
colIdx = 1;			% index variable to populate m/z (mass) numbers
resultMatrix = [];	% resulting fully stitched data matrix
columnSubMatrix = []; % holds sub matrix, all channel data for a group

for groupCounter = 1:length(groupStruct)	% process data from each group
	fullDataMat = groupStruct(groupCounter).scanData;	% ful data matrix for this group
	startScan = groupStruct(groupCounter).ghStartScan;	% start scan number for group
	endScan = startScan+groupStruct(groupCounter).ghNumScans-1;	% end scan number for group
	scanNums = [startScan:endScan];	% actual scan numbers for this group
	numScansInGroup = length(scanNums); % number of scans in this group
  
	for channelCounter = 1:nChannelsToPlot	% process each channel that matches the desired channelMode
		presentChannelNo = channelMatchIdxVect(channelCounter);	% extract present channel number data
		prevChannelNo = presentChannelNo-1;	% calculate previous channel for indexing
		
		% read relevant channel parameters
		channelStartMass = cell2mat(channelCell(3,presentChannelNo));	% 3 is start mass
		channelStopMass = cell2mat(channelCell(4,presentChannelNo));	% 4 is stop mass
		channelPpamu = cell2mat(channelCell(5,presentChannelNo));		% 5 is ppamu
		
		channelPtsToRead = channelPtsPerChanVect(presentChannelNo);
		presentAmuPts = [channelStartMass:1/channelPpamu:channelStopMass];	% store amu points associated with this channel
		dataStartCol = sum(channelPtsPerChanVect(1:prevChannelNo))+1;	% locate start column based on data points per channel
		dataEndCol = dataStartCol+channelPtsToRead-1;
		subDataMat = fullDataMat(:,[dataStartCol:dataEndCol]);	% extract only channel of interest from group data

    % 	if EM Enabled bit is set and measurement involves the quad, then change data polarity
		if emBit && (emAffectedSum>0)
			subDataMat = -subDataMat;
		end
  
		rowIdxRange = (rowIdx:rowIdx+numScansInGroup-1);
		scanNoVect(rowIdxRange) = scanNums;
		columnSubMatrix = horzcat(columnSubMatrix,subDataMat);	% add current channel data to channel sub matrix
		
		if (groupCounter == 1) 
			% store the mz (AMU) vector when the first group is read
			% channel start mass is less than stop for Baseline and othe vectors
			% explicit single check needed because this isn't true for singles
			if (channelStopMass < channelStartMass) || (strcmp(channelMode,'Single'))
				% this is a single point
				mzNoVect(colIdx) = channelStartMass;
				colIdx = colIdx + 1;
			else
				% this is a sweep
				mzNoVect(colIdx:colIdx+channelPtsToRead-1) = presentAmuPts;
				colIdx = colIdx + channelPtsToRead;
			end
		end

	end

	% this builds the result matrix by group (scans)	
	% after one complete channel submatrix is complete, add it to result matrix
	resultMatrix = vertcat(resultMatrix,columnSubMatrix);
	columnSubMatrix = []; % clear column sub matrix
	rowIdx = rowIdx+numScansInGroup;
end

% plot resulting data based on type and number of channelMode channels
[nRows nCols] = size(resultMatrix);

if nCols == 1
	% only one column of data, generate a 2D plot
	figure
	xDat = scanNoVect;
	yDat = resultMatrix(:,1);
	plot(xDat,yDat)
	grid on
	titlestr = sprintf('Channel Mode: %s, Channel Number: %d',...
		channelMode, channelMatchIdxVect(1));
	title(titlestr)
	xlabel('Scan Number');
	ylabel('Value');
	
	% add a legend to show the mass if this was a Single plot
	if (strcmp(channelMode,'Single'))
		legendCell = {};
		for legendCount = 1:length(mzNoVect)
			legendCell(legendCount) = sprintf('Mass %d',mzNoVect(legendCount));
		end
		legend(legendCell,'location','EastOutside')
	end
else
	% multiple channels to plot
	if (strcmp(channelMode,'Single'))
		% singls scans, generate 2D overlay plot
		figure
		if multiChannelSemilogY
			semilogy(scanNoVect,resultMatrix')
		else
			plot(scanNoVect,resultMatrix')
		end
		grid on
		legendCell = {};
		for legendCount = 1:length(mzNoVect)
			legendCell(legendCount) = sprintf('Mass %d',mzNoVect(legendCount));
		end
		titlestr = sprintf('Channel Mode: %s',channelMode);
		title(titlestr)
		xlabel('Scan Number');
		if multiChannelSemilogY
			ylabel('Amplitude Log(A)');
		else
			ylabel('Amplitude (A)');
		end
		
		legend(legendCell,'location','EastOutside')
	else
		% scan data, draw 3D mesh plot
		figure
		% todo: try scatter3 with single plot, will need to repmat
		% use view([270 0]) for profile view, view(3) to reset default view
		meshz(scanNoVect,mzNoVect,resultMatrix')
		set(gca,'ydir','reverse')	% reverse direction so amu increases left to right
		%titlestr = sprintf('Channel Mode: %s, Channel Number: %d',...
		%	channelMode, tgtModeNumber);
		titlestr = sprintf('Channel Mode: %s',channelMode);
		title(titlestr)
		ylabel('{\it m/z}');	
		xlabel('Scan Number');
		zlabel('Amplitude (A)');
	end
end
