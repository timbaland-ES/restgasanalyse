function [header channel groupStruct] = import_linxon_binary(binfilename, varargin)
% Import binary scan data file from Linxon myRGA Residual Gas Analyzer
%
% [HEADER CHANNEL GROUPSTRUCT] = IMPORT_LINXON_BINARY(BINFILENAME, OPTION)
%
% Load Linxon binary file BINFILENAME and parse data into structures HEADER,
% CHANNEL, and GROUPSTRUCT where
%
% 	HEADER contains the firmware version string of the Linxon myRGA, the
% 	number of channels, and the name of the binary file that was imported		
%
% 	CHANNEL contains information on the configuration of each channel,
%	including its mode
%
% 	GROUPSTRUCT contains data for each channel, and is arranged into scan
% 	groups
% 
% Optional input arguments:
%
%	DEBUG - Set to output debugging information (default: 0) while parsing
%	binary file
%
%	SAVEMATFILE - Set to save a MATLAB MAT file with the same base filename
%	as BINFILENAME in the current directory.  The MAT file will contain
%	structures HEADER, CHANNEL, and GROUPSTRUCT. (default: 1)
%
% The resulting data structures may be plotted using plot_linxon_structure
%
% Refer to the Linxon API document for additional information
%
% See also plot_linxon_structure

% input argument defaults
debug = 0;			% set to print debug information
saveMatFile = 1;	% save structure variables to mat file

% define constants
startWordHex = '244D5344';	% indicates start of capture file
revStartWordHex = '44534D24';	% endian reversed version of start word

% initialize variables
endianStr = 'b';	% alias for 'ieee-be', big-endian
byteTotal = 0;		% tracks number of bytes read

% process input arguments
if length(varargin) > 1
	for argcount = 1:2:length(varargin)-1
		switch lower(char(varargin(argcount)))
			case 'debug'
				debug = varargin{argcount+1};
			case 'savematfile'
				saveMatFile = varargin{argcount+1};				
			otherwise
				fprintf('Warning: switch %s is invalid and was neglected\n',...
					char(varargin(argcount)))
		endswitch
	end
end

% create base filename for saving mat file if needed
if saveMatFile
	dotLoc = strfind(binfilename,'.');
	
	if length(dotLoc)>1
		dotLoc = dotLoc(end);
	end
	
	basefname = binfilename(1:dotLoc-1);
	outFname = strcat(basefname,'.mat');
end

% open input file for reading in binary mode
fprintf('Opening binary file %s\n',binfilename)
fid = fopen(binfilename,'rb');

try

% read header data, determine endianness
startWordReadDec= fread(fid,1,'uint32',endianStr);

if startWordReadDec == hex2dec(startWordHex)
	% default endianness is correct
	if debug
		fprintf('default endianness %s is correct\n',endianStr)
	end
elseif startWordReadDec == hex2dec(revStartWordHex)
	if debug
		fprintf('default endianness %s is incorrect, switching\n',endianStr)
	end
	switch endianStr
		case 'l'
			endianStr = 'b'; % alias for 'ieee-be', big-endian
		case 'b'
			endianStr = 'l'; % alias for 'ieee-le', little-endian
		otherwise
			% error, unable to determie endianness
	endswitch
end

data = fread(fid,32,'uchar',endianStr);
header.versionStr = deblank(char(data)');
header.numChannels = fread(fid,1,'uint32',endianStr);

% add the name of the input data file to the header
header.inputFileName = binfilename;

if debug
	header
end

% read channel descriptor for each channel
for kk = 1:header.numChannels
	channel(kk).mode = {deblank(char(fread(fid,32,'uchar',endianStr))')};
	channel(kk).enabled = fread(fid,1,'uint16',endianStr);
	channel(kk).startMass = fread(fid,1,'uint16',endianStr)/1e2; % convert from centiAMU
	channel(kk).stopMass = fread(fid,1,'uint16',endianStr)/1e2; % convert from centiAMU
	channel(kk).ppamu = fread(fid,1,'uint16',endianStr);
	channel(kk).extra = fread(fid,1,'uint16',endianStr);
	channel(kk).dwell = fread(fid,1,'uint16',endianStr);
	channel(kk).dataFormat = fread(fid,1,'uint16',endianStr);
	channel(kk).ptsPerChannel = fread(fid,1,'uint16',endianStr);
		
	if debug
		channel(kk)
	end
end

% read scan groups
groupNum = 1;
fileStatus = 0;	% will be set if last read resulted in eof

while fileStatus == 0	% read remainder of the file, which contains scan group data
	
	ghFieldNames = {'ghStartScan',...
		'ghNumScans',...
		'ghPointsPerScan',...
		'ghErrorDropped',...
		'ghErrorOverflow',...
		'ghReserved'};
	
	for i = 1:length(ghFieldNames)
		groupStruct(groupNum).(ghFieldNames{i})=fread(fid,1,'uint32',endianStr);
	end
	
	% check if the last attempted read resulted in eof
	fileStatus = feof(fid);
	
	if fileStatus
		% the last reads resulted in null data due to eof
		% remove last groupStruct entry
		groupStruct = groupStruct(1:groupNum-1);
		break
	end
	
	if debug
		groupStruct(groupNum)
	end
		
	% initialize variables to hold scan data for current group
	scanData = zeros(groupStruct(groupNum).ghNumScans,groupStruct(groupNum).ghPointsPerScan);
	scanIndex = groupStruct(groupNum).ghStartScan:...
					groupStruct(groupNum).ghStartScan+groupStruct(groupNum).ghNumScans-1;
	
	% read scan groups
	for scanCount = 1:groupStruct(groupNum).ghNumScans
		pointIndex = 1;
		for chanCount = 1:header.numChannels
			for chanPointCount = 1:channel(chanCount).ptsPerChannel
				switch channel(chanCount).dataFormat
					case 1
						currentWord = fread(fid,1,'float32',endianStr);
						if debug && (scanCount == 1) && (mod(pointIndex,5)==0)
							fprintf('scanCount=%i,chanPointCount=%i,pointIndex=%i,float32=%2.2e\n',...
								scanCount,chanPointCount,pointIndex,currentWord)
						end
						scanData(scanCount,pointIndex) = currentWord;
						dataTypeVect(pointIndex) = channel(chanCount).dataFormat;
						pointIndex = pointIndex+1;
					case 2
						currentWord = fread(fid,1,'uint32',endianStr);
						if debug && (scanCount == 1) && (mod(pointIndex,5)==0)
							fprintf('scanCount=%i,chanPointCount=%i,pointIndex=%i,uint32=0x%s (%id)\n',...
								scanCount,chanPointCount,pointIndex,dec2hex(currentWord),currentWord)
						end
						scanData(scanCount,pointIndex) = currentWord;
						dataTypeVect(pointIndex) = channel(chanCount).dataFormat;
						pointIndex = pointIndex+1;
					otherwise
						% this is an error, unsupported data type
				endswitch
			end
		end
	end
	
	% store scan data for current group
	groupStruct(groupNum).scanData = scanData;
	groupStruct(groupNum).dataTypeVect = dataTypeVect;
	
	if debug
		groupStruct(groupNum)
	end
	
	groupNum = groupNum + 1;
	
	fileStatus = feof(fid);
end

% file reads complete, close file
fclose(fid);

if saveMatFile
	fprintf('Saving MAT file %s\n',outFname);
	save(outFname,'header','channel','groupStruct');
end

catch
	fprintf('Catch hit\n')
	fprintf('Last error: %s\n',lasterr);
	fclose(fid);
end

return
