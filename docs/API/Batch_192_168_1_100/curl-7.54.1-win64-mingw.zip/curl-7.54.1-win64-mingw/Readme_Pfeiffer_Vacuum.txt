PFEIFFER VACUUM 
02/08/2017
TH. Busch R&D MA

*****************************************************************************
Copy folder cURL to e.g. c:\
Execute curl.exe from ...\bin\
Install Certificate curl-ca-bundle.crt from ...\bin\	(right mouse click)

Copy curl.exe to c:\Windows\
(You must have administrator rights)

open cmd	(Keybord "win" + "R")

type e.g.:

c:\>curl --help
or
c:\>curl 192.168.1.100/mmsp/communication/ipAddress/get